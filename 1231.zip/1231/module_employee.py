import datetime as DT


def str_to_date(self_date, other_date):
    dt1 = self_date.split(".")
    dt2 = other_date.split(".")
    self_bdate = DT.date(int(dt1[2]), int(dt1[1]), int(dt1[0]))
    other_bdate = DT.date(int(dt2[2]), int(dt2[1]), int(dt2[0]))
    return self_bdate, other_bdate


class Products:
    def __init__(self, products, price, quantity, discount, measurements, on_leave=False):
        self.products = products
        self.price = price
        self.quantity = quantity
        self.discount = discount
        self.measurements = measurements
        self.on_leave = on_leave

    # Здесь и ниже операции сравнения >, >=, <, <=, ==, !=
    def __lt__(self, other):  # <
        self_price, other_price = (self.price, other.price)
        return self_price < other_price

    def __eq__(self, other):  # ==
        self_price, other_price = (self.price, other.price)
        return self_price == other_price

    def __le__(self, other):  # <=
        if self.__eq__(other):
            return True

        if self.__lt__(other):
            return True
        else:
            return False
#     # Изменяем оклад
#     def increase_salary(self, summa):
#         self.salary += summa
#
#     # Перехват функции print, когда она преобразует свое значение в строку
#     def __str__(self):
#         return f"Сотрудник {self.number} {self.fio}, {self.bdate}," \
#                f" оклад: {self.salary}, в отпуске: {'да' if self.on_leave else 'нет'}"
#
#
#
#
class Cassa:
    def __init__(self, product, date, productss=None, summa):
        self.product = product
        self.date = date
        if productss is None:
            productss = list()
        self.productss = productss
        self.summa = summa

    # Добавляем сотрудника в отдел
    def append(self, emp):
        self.employees.append(emp)

    # Перехват функции print, когда она преобразует свое значение в строку
    # Возврат информации об отделе
    def __str__(self):
        return f"Отдел: {self.title}, Начальник: {self.chief.fio}, Количество сотрудников: {len(self.employees)} "

    # Вывод сотрудников отдела
    def print_employees(self):
        for emp in self.employees:
            print(emp)

    # Вывод сотрудников отдела в отпуске/не в отпуске
    def print_employees_on_leave(self, status=True):
        for emp in self.employees:
            if emp.on_leave == status:
                print(emp.number, emp.fio)


class1 =Products(1, 'Гречка', 110, 100, 34, 'кг')
class2 =Products(2, 'Рис', 90,  110, 23, 'кг')
class3 =Products(3, 'Сыр', 140,  120, 32, 'кг')
# Сравние твара по цене
print(class1 < class2)
print(class1 <= class2)
print(class1 >= class2)



# depart_1 = Department('архив', emp_1)
# depart_1.append(emp_1)
# depart_1.append(emp_2)
# print(depart_1)
# depart_1.print_employees()
# emp_1.increase_salary(1333)
# emp_1.on_leave = True
# emp_2.on_leave = True
# print(emp_1)
# depart_1.print_employees_on_leave()
