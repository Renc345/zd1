import pandas

csv_file = None
menu = {
    '1': 'Открыть файл',
    '2': 'Добавить',
    '3': 'Вывести в алфавитном порядке товары',
    '4': 'Вывести записи со скидкой более чем указанная',
    '5': 'Вывести самый дорогой товар',
    '6': 'Сохранить в файл',
    '7': 'Вывести количество проданных товаров в указанную дату',
    '8': 'Вывести все товары, проданные в указанную дату',
    '9': 'Вывести кол-во товара указанной уд. изм',
    '0': '<-Меню',
    'exit': 'Выход'
}


def file_open():
    try:
        data = pandas.read_csv('data (1).csv', delimiter=";")
    except Exception as e:
        print(e)
    print('Файл открыт. Записей:', len(data.index))
    return data


def insert(product, price, quantity, discount, measurements, date):
    global csv_file
    df_insert = pandas.DataFrame([(max(csv_file['номер'] + 1), product, price, quantity, discount, measurements, date)],
                                 columns=(
                                     'номер', 'товар', 'цена', 'количество', 'скидка', 'ед. измерения', 'дата продажи'))
    df2 = pandas.concat([csv_file, df_insert])
    return df2


def drop_by_arg(val, col_name='фио'):
    global csv_file
    if col_name == 'ном' or col_name == 'возраст':
        val = int(val)
    csv_file = csv_file.set_index(col_name)
    csv_file.drop(val, axis=0, inplace=True)
    print(csv_file)


def find(val, col_name='фио'):
    df = csv_file[csv_file[col_name].isin([val])]
    print(df)


def max_price():
    print("Самый дорогой товар:", csv_file.loc[csv_file["цена"] == csv_file["цена"].max()])


def date_price_kol(date):
    rez_df = csv_file.loc[csv_file["товар"] == date]
    return f"Количество проданных товаров: {len(rez_df)}"


def print_tovari(date):
    rez_df = csv_file.loc[csv_file["дата продажи"] == date]
    print(rez_df)


def sales(date):
    rez_df = csv_file.loc[csv_file["скидка"] > date]
    print(rez_df)


def save():
    try:
        csv_file.to_csv('data.csv', index=False, sep=';')
    except Exception as e:
        print(e)


def kol_ed(date):
    rez_df = csv_file.loc[csv_file["ед. измерения"] == date]
    return f"Количество товаров: {len(rez_df)}"


# Вывод меню
print('\n'.join([f"{k} : {v}" for k, v in menu.items()]))
while True:
    comand = input()
    if comand == '1':
        csv_file = file_open()
    elif comand == '2':
        csv_file = insert(input('Товар: '), input('Цена: '),
                          input('Количество: '), input('Скидка: '),
                          input('Ед. измерения: '), input('Дата продажи: '))
        print(csv_file)
    elif comand == '3':
        print(csv_file['товар'].sort_values())
    elif comand == '4':
        sales(20)
    elif comand == '5':
        max_price()
    elif comand == '6':
        save()
    elif comand == '7':
        print(date_price_kol(input("Введите дату: ")))
    elif comand == '8':
        print_tovari('14.11.2022')
    elif comand == '9':
        print(kol_ed(input("Введите ед. измерения: ")))
    elif comand == '0':
        print('\n'.join([f"{k} : {v}" for k, v in menu.items()]))
    else:
        break
